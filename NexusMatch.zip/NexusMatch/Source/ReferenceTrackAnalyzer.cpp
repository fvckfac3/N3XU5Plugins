#include "ReferenceTrackAnalyzer.h"

ReferenceTrackAnalyzer::ReferenceTrackAnalyzer()
{
    formatManager.registerBasicFormats(); // WAV, AIFF, FLAC, OGG, and read-only MP3
    curveDb.fill (-100.0f);
}

ReferenceTrackAnalyzer::~ReferenceTrackAnalyzer()
{
    if (workerThread.joinable())
        workerThread.join();
}

void ReferenceTrackAnalyzer::loadAndAnalyzeAsync (const juce::File& file)
{
    if (workerThread.joinable())
        workerThread.join(); // let any previous analysis finish first

    ready = false;
    analyzing = true;
    loadedFileName = file.getFileName();

    workerThread = std::thread ([this, file] { runAnalysis (file); });
}

void ReferenceTrackAnalyzer::runAnalysis (juce::File file)
{
    std::unique_ptr<juce::AudioFormatReader> reader (formatManager.createReaderFor (file));
    if (reader == nullptr)
    {
        analyzing = false;
        return;
    }

    constexpr int fftOrder = 12;
    constexpr int fftSize = 1 << fftOrder;
    juce::dsp::FFT fft (fftOrder);
    juce::dsp::WindowingFunction<float> window ((size_t) fftSize, juce::dsp::WindowingFunction<float>::hann);

    auto centres = BandLayout::getCenterFrequencies();
    const float binHz = (float) reader->sampleRate / (float) fftSize;
    std::array<float, BandLayout::kNumBands> lowerBin {}, upperBin {};
    for (int i = 0; i < BandLayout::kNumBands; ++i)
    {
        const float lowerFreq = (i == 0)
            ? BandLayout::kMinFreq * 0.5f
            : std::sqrt (centres[(size_t) i - 1] * centres[(size_t) i]);
        const float upperFreq = (i == BandLayout::kNumBands - 1)
            ? BandLayout::kMaxFreq * 1.2f
            : std::sqrt (centres[(size_t) i] * centres[(size_t) i + 1]);
        lowerBin[(size_t) i] = juce::jmax (1.0f, lowerFreq / binHz);
        upperBin[(size_t) i] = juce::jmin ((float) (fftSize / 2), upperFreq / binHz);
    }

    std::array<double, BandLayout::kNumBands> accum {};
    accum.fill (0.0);
    long long frameCount = 0;

    juce::AudioBuffer<float> block (juce::jmax (1, (int) reader->numChannels), fftSize);
    std::array<float, fftSize * 2> fftBuffer {};

    juce::int64 position = 0;
    const juce::int64 total = reader->lengthInSamples;
    const int hop = fftSize / 2; // 50% overlap

    while (position + fftSize < total)
    {
        block.clear();
        reader->read (&block, 0, fftSize, position, true, true);

        for (int i = 0; i < fftSize; ++i)
        {
            float sum = 0.0f;
            for (int ch = 0; ch < block.getNumChannels(); ++ch)
                sum += block.getSample (ch, i);
            fftBuffer[(size_t) i] = sum / (float) juce::jmax (1, block.getNumChannels());
        }
        std::fill (fftBuffer.begin() + fftSize, fftBuffer.end(), 0.0f);

        window.multiplyWithWindowingTable (fftBuffer.data(), fftSize);
        fft.performFrequencyOnlyForwardTransform (fftBuffer.data());

        for (int b = 0; b < BandLayout::kNumBands; ++b)
        {
            const int lo = (int) lowerBin[(size_t) b];
            const int hi = juce::jmax (lo + 1, (int) upperBin[(size_t) b]);
            double sumSq = 0.0;
            int count = 0;
            for (int bin = lo; bin < hi && bin < fftSize / 2; ++bin)
            {
                const float mag = fftBuffer[(size_t) bin] / (float) fftSize;
                sumSq += (double) mag * mag;
                count++;
            }
            accum[(size_t) b] += (count > 0 ? sumSq / count : 1.0e-12);
        }

        frameCount++;
        position += hop;
    }

    std::array<float, BandLayout::kNumBands> result {};
    double mean = 0.0;
    for (int b = 0; b < BandLayout::kNumBands; ++b)
    {
        const double meanSq = frameCount > 0 ? accum[(size_t) b] / (double) frameCount : 1.0e-12;
        result[(size_t) b] = (float) juce::Decibels::gainToDecibels (std::sqrt (meanSq), -100.0);
        mean += result[(size_t) b];
    }
    mean /= BandLayout::kNumBands;

    // Normalize so the curve represents spectral *shape*, not level — loudness
    // matching is a separate concern (that's the metering plugin's job).
    for (auto& v : result) v -= (float) mean;

    {
        juce::ScopedLock lock (curveLock);
        curveDb = result;
    }
    ready = true;
    analyzing = false;
}

std::array<float, BandLayout::kNumBands> ReferenceTrackAnalyzer::getCurve() const
{
    juce::ScopedLock lock (curveLock);
    return curveDb;
}
