#include "PluginProcessor.h"
#include "PluginEditor.h"

NexusMatchAudioProcessor::NexusMatchAudioProcessor()
    : AudioProcessor (BusesProperties()
                         .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                         .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMETERS", createParameterLayout())
{
}

juce::AudioProcessorValueTreeState::ParameterLayout NexusMatchAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "amount", "Match Amount",
        juce::NormalisableRange<float> (0.0f, 100.0f, 1.0f), 75.0f));

    params.push_back (std::make_unique<juce::AudioParameterBool> ("bypass", "Bypass", false));

    return { params.begin(), params.end() };
}

void NexusMatchAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    liveAnalyzer.prepare (sampleRate, samplesPerBlock);

    juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) samplesPerBlock,
                                   (juce::uint32) juce::jmax (1, getTotalNumOutputChannels()) };
    matchingEq.prepare (spec);
}

bool NexusMatchAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto mono = juce::AudioChannelSet::mono();
    const auto stereo = juce::AudioChannelSet::stereo();
    auto in = layouts.getMainInputChannelSet();
    auto out = layouts.getMainOutputChannelSet();
    if (in != out) return false;
    return in == mono || in == stereo;
}

void NexusMatchAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    // Analyze the untreated input so the live curve reflects what's actually
    // coming in, not the corrected output — otherwise the matching filter
    // would be chasing its own tail.
    liveAnalyzer.processBlock (buffer);

    const bool bypassed = apvts.getRawParameterValue ("bypass")->load() > 0.5f;
    if (! bypassed)
    {
        juce::dsp::AudioBlock<float> block (buffer);
        matchingEq.process (juce::dsp::ProcessContextReplacing<float> (block));
    }
}

void NexusMatchAudioProcessor::updateMatchingFilters()
{
    if (! referenceAnalyzer.isReady())
        return;

    auto liveCurve = liveAnalyzer.getCurve();
    auto refCurve = referenceAnalyzer.getCurve();
    const float amount = apvts.getRawParameterValue ("amount")->load() / 100.0f;

    // Normalize the live curve the same way the reference was normalized
    // (subtract its own mean) so shape is being compared to shape, not
    // absolute level to absolute level.
    float liveMean = 0.0f;
    for (float v : liveCurve) liveMean += v;
    liveMean /= (float) liveCurve.size();

    std::array<float, BandLayout::kNumBands> target {};
    for (size_t i = 0; i < target.size(); ++i)
    {
        const float liveShape = liveCurve[i] - liveMean;
        const float diff = refCurve[i] - liveShape;
        target[i] = diff * amount;
    }

    matchingEq.setTargetCurve (target);
}

juce::AudioProcessorEditor* NexusMatchAudioProcessor::createEditor()
{
    return new NexusMatchAudioProcessorEditor (*this);
}

void NexusMatchAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void NexusMatchAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, sizeInBytes));
    if (xml != nullptr && xml->hasTagName (apvts.state.getType()))
        apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new NexusMatchAudioProcessor();
}
