#pragma once
#include <array>
#include <cmath>

/**
    Defines the log-spaced frequency bands shared by the live spectrum
    analyzer, the offline reference-track analyzer, and the matching EQ's
    filter bank — all three must agree on the same centre frequencies for
    the curves to line up and the diff-to-filter mapping to make sense.
*/
namespace BandLayout
{
    constexpr int kNumBands = 24;
    constexpr float kMinFreq = 20.0f;
    constexpr float kMaxFreq = 20000.0f;

    inline std::array<float, kNumBands> getCenterFrequencies()
    {
        std::array<float, kNumBands> freqs {};
        const float logMin = std::log10 (kMinFreq);
        const float logMax = std::log10 (kMaxFreq);
        for (int i = 0; i < kNumBands; ++i)
        {
            const float t = (float) i / (float) (kNumBands - 1);
            freqs[(size_t) i] = std::pow (10.0f, logMin + t * (logMax - logMin));
        }
        return freqs;
    }
}
