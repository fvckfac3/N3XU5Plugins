#pragma once
#include <juce_dsp/juce_dsp.h>
#include "BandLayout.h"

/**
    MatchingEQ
    -----------
    A bank of peaking filters, one per BandLayout band, that reshapes the
    live signal toward a target curve. Call setTargetCurve() with the
    desired per-band gain (dB, already scaled by the user's "amount" blend)
    whenever the target changes; process() runs the filters on audio as
    normal.

    THREADING NOTE: setTargetCurve() reassigns each filter's
    juce::dsp::IIR::Coefficients::Ptr — a reference-counted pointer swap.
    This is the standard approach shown in JUCE's own tutorials and is safe
    in practice as long as it isn't called at audio-block rate. This project
    calls it a few times a second from a UI timer (see PluginEditor), not
    from processBlock — don't move that call onto the audio thread without
    switching to a proper lock-free parameter-smoothing scheme.
*/
class MatchingEQ
{
public:
    void prepare (const juce::dsp::ProcessSpec& spec);
    void reset();
    void process (juce::dsp::ProcessContextReplacing<float> context);

    /** gainsDb.size() == BandLayout::kNumBands, already blended by "amount". */
    void setTargetCurve (const std::array<float, BandLayout::kNumBands>& gainsDb);

private:
    double sampleRate = 44100.0;

    using Filter = juce::dsp::IIR::Filter<float>;
    using Coeffs = juce::dsp::IIR::Coefficients<float>;

    std::array<juce::dsp::ProcessorDuplicator<Filter, Coeffs>, BandLayout::kNumBands> bands;
    std::array<float, BandLayout::kNumBands> centreFrequencies = BandLayout::getCenterFrequencies();
};
