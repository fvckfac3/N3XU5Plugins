#include "PluginEditor.h"

NexusMatchAudioProcessorEditor::NexusMatchAudioProcessorEditor (NexusMatchAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    addAndMakeVisible (curveDisplay);

    loadReferenceButton.onClick = [this] { chooseReferenceFile(); };
    addAndMakeVisible (loadReferenceButton);

    statusLabel.setText ("No reference loaded", juce::dontSendNotification);
    statusLabel.setColour (juce::Label::textColourId, juce::Colours::white.withAlpha (0.6f));
    statusLabel.setFont (juce::Font (juce::FontOptions (13.0f)));
    addAndMakeVisible (statusLabel);

    amountSlider.setSliderStyle (juce::Slider::LinearHorizontal);
    amountSlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, 50, 20);
    addAndMakeVisible (amountSlider);
    addAndMakeVisible (amountLabel);
    amountAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, "amount", amountSlider);

    addAndMakeVisible (bypassButton);
    bypassAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        audioProcessor.apvts, "bypass", bypassButton);

    setSize (680, 460);
    setResizable (true, true);
    setResizeLimits (500, 360, 1200, 800);

    startTimerHz (10);
}

void NexusMatchAudioProcessorEditor::chooseReferenceFile()
{
    fileChooser = std::make_unique<juce::FileChooser> (
        "Select a reference track...", juce::File(), "*.wav;*.aif;*.aiff;*.mp3;*.flac");

    const auto flags = juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles;

    fileChooser->launchAsync (flags, [this] (const juce::FileChooser& fc)
    {
        auto file = fc.getResult();
        if (file != juce::File())
        {
            statusLabel.setText ("Analyzing " + file.getFileName() + "...", juce::dontSendNotification);
            audioProcessor.referenceAnalyzer.loadAndAnalyzeAsync (file);
        }
    });
}

void NexusMatchAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff0a0a0f));
    g.setColour (juce::Colours::white);
    g.setFont (juce::Font (juce::FontOptions (20.0f)).withTypefaceStyle ("Bold"));
    g.drawText ("NEXUS MATCH", getLocalBounds().removeFromTop (36).reduced (12, 0),
                juce::Justification::centredLeft);
}

void NexusMatchAudioProcessorEditor::resized()
{
    auto bounds = getLocalBounds().reduced (12);
    bounds.removeFromTop (30);

    auto topRow = bounds.removeFromTop (30);
    loadReferenceButton.setBounds (topRow.removeFromLeft (180));
    topRow.removeFromLeft (12);
    bypassButton.setBounds (topRow.removeFromRight (90));
    statusLabel.setBounds (topRow);

    bounds.removeFromTop (10);

    auto amountRow = bounds.removeFromTop (28);
    amountLabel.setBounds (amountRow.removeFromLeft (100));
    amountSlider.setBounds (amountRow);

    bounds.removeFromTop (10);
    curveDisplay.setBounds (bounds);
}

void NexusMatchAudioProcessorEditor::timerCallback()
{
    curveDisplay.setLiveCurve (audioProcessor.liveAnalyzer.getCurve());

    if (audioProcessor.referenceAnalyzer.isReady())
    {
        curveDisplay.setReferenceCurve (audioProcessor.referenceAnalyzer.getCurve(), true);
        statusLabel.setText ("Reference: " + audioProcessor.referenceAnalyzer.getLoadedFileName(),
                              juce::dontSendNotification);
    }
    else if (audioProcessor.referenceAnalyzer.isAnalyzing())
    {
        statusLabel.setText ("Analyzing reference track...", juce::dontSendNotification);
    }

    // Throttle filter coefficient recomputation to a few times a second —
    // see MatchingEQ's threading note for why this isn't done per-block.
    if (++timerTickCount % 3 == 0)
        audioProcessor.updateMatchingFilters();
}
