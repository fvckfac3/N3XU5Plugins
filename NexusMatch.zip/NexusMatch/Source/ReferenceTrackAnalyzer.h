#pragma once
#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_dsp/juce_dsp.h>
#include "BandLayout.h"
#include <thread>
#include <atomic>

/**
    ReferenceTrackAnalyzer
    ------------------------
    Loads a user-picked audio file and computes its average spectral shape
    (same band layout as SpectrumAnalyzer), normalized so the curve
    represents tonal *balance* rather than absolute loudness — a bright,
    quiet reference and a bright, loud reference should produce the same
    shape.

    File IO + FFT-over-the-whole-file is done on a std::thread so a long
    reference track doesn't freeze the plugin UI or (worse) the message
    thread of the host. isReady()/isAnalyzing() let the UI poll status;
    getCurve() is safe to call from the UI timer once isReady() is true.
*/
class ReferenceTrackAnalyzer
{
public:
    ReferenceTrackAnalyzer();
    ~ReferenceTrackAnalyzer();

    /** Non-blocking — kicks off analysis on a background thread. */
    void loadAndAnalyzeAsync (const juce::File& file);

    bool isReady() const     { return ready.load(); }
    bool isAnalyzing() const { return analyzing.load(); }
    juce::String getLoadedFileName() const { return loadedFileName; }

    std::array<float, BandLayout::kNumBands> getCurve() const;

private:
    void runAnalysis (juce::File file);

    juce::AudioFormatManager formatManager;
    std::thread workerThread;
    std::atomic<bool> ready { false };
    std::atomic<bool> analyzing { false };
    juce::String loadedFileName;

    mutable juce::CriticalSection curveLock;
    std::array<float, BandLayout::kNumBands> curveDb {};
};
