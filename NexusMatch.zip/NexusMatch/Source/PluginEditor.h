#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include "CurveDisplay.h"

class NexusMatchAudioProcessorEditor : public juce::AudioProcessorEditor,
                                        private juce::Timer
{
public:
    explicit NexusMatchAudioProcessorEditor (NexusMatchAudioProcessor&);
    ~NexusMatchAudioProcessorEditor() override = default;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void chooseReferenceFile();

    NexusMatchAudioProcessor& audioProcessor;

    CurveDisplay curveDisplay;
    juce::TextButton loadReferenceButton { "Load Reference Track..." };
    juce::Label statusLabel;
    juce::Slider amountSlider;
    juce::Label amountLabel { {}, "Match Amount" };
    juce::ToggleButton bypassButton { "Bypass" };

    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> amountAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttachment;
    std::unique_ptr<juce::FileChooser> fileChooser;

    int timerTickCount = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (NexusMatchAudioProcessorEditor)
};
