#include "SpectrumAnalyzer.h"

void SpectrumAnalyzer::prepare (double sampleRate, int)
{
    sr = sampleRate;
    fifoIndex = 0;
    fifo.fill (0.0f);
    smoothedCurveDb.fill (-100.0f);
    computeBandEdges();
}

void SpectrumAnalyzer::reset()
{
    fifoIndex = 0;
    fifo.fill (0.0f);
    juce::ScopedLock lock (curveLock);
    smoothedCurveDb.fill (-100.0f);
}

void SpectrumAnalyzer::computeBandEdges()
{
    // Each band's edges sit at the geometric midpoint between its centre
    // and its neighbours' centres, so adjacent bands tile the spectrum
    // without gaps or overlap.
    auto centres = BandLayout::getCenterFrequencies();
    const float binHz = (float) sr / (float) fftSize;

    for (int i = 0; i < BandLayout::kNumBands; ++i)
    {
        const float lowerFreq = (i == 0)
            ? BandLayout::kMinFreq * 0.5f
            : std::sqrt (centres[(size_t) i - 1] * centres[(size_t) i]);
        const float upperFreq = (i == BandLayout::kNumBands - 1)
            ? BandLayout::kMaxFreq * 1.2f
            : std::sqrt (centres[(size_t) i] * centres[(size_t) i + 1]);

        bandLowerBin[(size_t) i] = juce::jmax (1.0f, lowerFreq / binHz);
        bandUpperBin[(size_t) i] = juce::jmin ((float) (fftSize / 2), upperFreq / binHz);
    }
}

void SpectrumAnalyzer::pushSample (float sample)
{
    if (fifoIndex == fftSize)
    {
        performAnalysis();
        fifoIndex = 0;
    }
    fifo[(size_t) fifoIndex++] = sample;
}

void SpectrumAnalyzer::processBlock (const juce::AudioBuffer<float>& buffer)
{
    const int numChans = buffer.getNumChannels();
    const int numSamples = buffer.getNumSamples();

    for (int i = 0; i < numSamples; ++i)
    {
        float sum = 0.0f;
        for (int ch = 0; ch < numChans; ++ch)
            sum += buffer.getSample (ch, i);
        pushSample (sum / (float) juce::jmax (1, numChans));
    }
}

void SpectrumAnalyzer::performAnalysis()
{
    std::copy (fifo.begin(), fifo.end(), fftBuffer.begin());
    std::fill (fftBuffer.begin() + fftSize, fftBuffer.end(), 0.0f);

    window.multiplyWithWindowingTable (fftBuffer.data(), fftSize);
    fft.performFrequencyOnlyForwardTransform (fftBuffer.data());

    std::array<float, BandLayout::kNumBands> instant {};
    for (int b = 0; b < BandLayout::kNumBands; ++b)
    {
        const int lo = (int) bandLowerBin[(size_t) b];
        const int hi = juce::jmax (lo + 1, (int) bandUpperBin[(size_t) b]);

        double sumSq = 0.0;
        int count = 0;
        for (int bin = lo; bin < hi && bin < fftSize / 2; ++bin)
        {
            const float mag = fftBuffer[(size_t) bin] / (float) fftSize;
            sumSq += (double) mag * mag;
            count++;
        }
        const double meanSq = count > 0 ? sumSq / count : 1.0e-12;
        instant[(size_t) b] = (float) juce::Decibels::gainToDecibels (std::sqrt (meanSq), -100.0);
    }

    juce::ScopedLock lock (curveLock);
    for (int b = 0; b < BandLayout::kNumBands; ++b)
    {
        const float coeff = instant[(size_t) b] > smoothedCurveDb[(size_t) b] ? attackCoeff : releaseCoeff;
        smoothedCurveDb[(size_t) b] += coeff * (instant[(size_t) b] - smoothedCurveDb[(size_t) b]);
    }
}

std::array<float, BandLayout::kNumBands> SpectrumAnalyzer::getCurve() const
{
    juce::ScopedLock lock (curveLock);
    return smoothedCurveDb;
}
