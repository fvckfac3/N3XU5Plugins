#pragma once
#include <juce_dsp/juce_dsp.h>
#include "BandLayout.h"

/**
    SpectrumAnalyzer
    -----------------
    Continuously analyzes an incoming audio stream and maintains a smoothed,
    per-band (see BandLayout) dB curve — this is the "live" side of the
    match: what your current input actually sounds like, tonally.

    Runs on the audio thread inside processBlock(); getCurve() is called
    from the UI timer and takes a lock to snapshot the data. The lock is
    held only long enough to copy a small array, so contention/priority
    inversion risk is low in practice, but note this isn't a formally
    lock-free design — acceptable for a UI-rate readout, not for anything
    audio-critical.
*/
class SpectrumAnalyzer
{
public:
    void prepare (double sampleRate, int maxBlockSize);
    void reset();
    void processBlock (const juce::AudioBuffer<float>& buffer);

    std::array<float, BandLayout::kNumBands> getCurve() const;

private:
    static constexpr int fftOrder = 12; // 4096-point FFT
    static constexpr int fftSize = 1 << fftOrder;

    double sr = 44100.0;
    juce::dsp::FFT fft { fftOrder };
    juce::dsp::WindowingFunction<float> window { (size_t) fftSize, juce::dsp::WindowingFunction<float>::hann };

    std::array<float, fftSize> fifo {};
    std::array<float, fftSize * 2> fftBuffer {};
    int fifoIndex = 0;

    std::array<float, BandLayout::kNumBands> bandLowerBin {};
    std::array<float, BandLayout::kNumBands> bandUpperBin {};

    mutable juce::CriticalSection curveLock;
    std::array<float, BandLayout::kNumBands> smoothedCurveDb {};

    static constexpr float attackCoeff = 0.6f;   // fast rise
    static constexpr float releaseCoeff = 0.05f; // slow fall, like a VU-ish ballistics

    void computeBandEdges();
    void pushSample (float sample);
    void performAnalysis();
};
