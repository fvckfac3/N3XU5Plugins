#include "MatchingEQ.h"

void MatchingEQ::prepare (const juce::dsp::ProcessSpec& spec)
{
    sampleRate = spec.sampleRate;
    for (int i = 0; i < BandLayout::kNumBands; ++i)
    {
        bands[(size_t) i].state = Coeffs::makePeakFilter (sampleRate, centreFrequencies[(size_t) i], 1.2, 1.0f);
        bands[(size_t) i].prepare (spec);
    }
}

void MatchingEQ::reset()
{
    for (auto& b : bands) b.reset();
}

void MatchingEQ::process (juce::dsp::ProcessContextReplacing<float> context)
{
    for (auto& b : bands)
        b.process (context);
}

void MatchingEQ::setTargetCurve (const std::array<float, BandLayout::kNumBands>& gainsDb)
{
    // Q chosen so 24 log-spaced peaking bands overlap smoothly into a
    // continuous curve rather than rippling like a comb filter. Widen this
    // (lower Q) if you add fewer bands; narrow it if you add more.
    constexpr double q = 1.2;

    for (int i = 0; i < BandLayout::kNumBands; ++i)
    {
        const float gainDb = juce::jlimit (-12.0f, 12.0f, gainsDb[(size_t) i]);
        const float linearGain = juce::Decibels::decibelsToGain (gainDb);
        bands[(size_t) i].state = Coeffs::makePeakFilter (sampleRate, centreFrequencies[(size_t) i], q, linearGain);
    }
}
