#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "BandLayout.h"

/** Overlays the live input's spectral shape against the loaded reference's target shape. */
class CurveDisplay : public juce::Component
{
public:
    void setLiveCurve (const std::array<float, BandLayout::kNumBands>& c)
    {
        // Display relative to its own mean, matching how the reference is normalized.
        float mean = 0.0f;
        for (float v : c) mean += v;
        mean /= (float) c.size();
        for (size_t i = 0; i < c.size(); ++i)
            liveCurve[i] = c[i] - mean;
        repaint();
    }

    void setReferenceCurve (const std::array<float, BandLayout::kNumBands>& c, bool valid)
    {
        refCurve = c;
        hasRef = valid;
        repaint();
    }

    void paint (juce::Graphics& g) override
    {
        auto bounds = getLocalBounds().toFloat();
        g.setColour (juce::Colour (0xff141420));
        g.fillRoundedRectangle (bounds, 4.0f);

        drawGrid (g, bounds);
        drawCurve (g, bounds, liveCurve, juce::Colour (0xff00e5c7));
        if (hasRef)
            drawCurve (g, bounds, refCurve, juce::Colour (0xffff9d2d));

        g.setColour (juce::Colours::white.withAlpha (0.6f));
        g.setFont (juce::Font (juce::FontOptions (11.0f)));
        g.drawText ("— live", bounds.removeFromTop (16.0f).removeFromLeft (60.0f).toNearestInt(),
                    juce::Justification::centredLeft);

        if (! hasRef)
        {
            g.setColour (juce::Colours::white.withAlpha (0.4f));
            g.setFont (juce::Font (juce::FontOptions (14.0f)));
            g.drawText ("Load a reference track to see the target curve",
                        getLocalBounds(), juce::Justification::centred);
        }
    }

private:
    std::array<float, BandLayout::kNumBands> liveCurve {};
    std::array<float, BandLayout::kNumBands> refCurve {};
    bool hasRef = false;

    void drawGrid (juce::Graphics& g, juce::Rectangle<float> bounds)
    {
        g.setColour (juce::Colours::white.withAlpha (0.08f));
        for (float db = -18.0f; db <= 18.0f; db += 6.0f)
        {
            const float y = juce::jmap (db, -24.0f, 24.0f, bounds.getBottom(), bounds.getY());
            g.drawHorizontalLine ((int) y, bounds.getX(), bounds.getRight());
        }
    }

    void drawCurve (juce::Graphics& g, juce::Rectangle<float> bounds,
                     const std::array<float, BandLayout::kNumBands>& curve, juce::Colour colour)
    {
        juce::Path path;
        for (int i = 0; i < BandLayout::kNumBands; ++i)
        {
            const float x = bounds.getX() + bounds.getWidth() * ((float) i / (float) (BandLayout::kNumBands - 1));
            const float y = juce::jmap (juce::jlimit (-24.0f, 24.0f, curve[(size_t) i]),
                                         -24.0f, 24.0f, bounds.getBottom(), bounds.getY());
            if (i == 0) path.startNewSubPath (x, y); else path.lineTo (x, y);
        }
        g.setColour (colour);
        g.strokePath (path, juce::PathStrokeType (2.0f));
    }
};
