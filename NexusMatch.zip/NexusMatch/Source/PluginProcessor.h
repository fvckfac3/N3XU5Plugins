#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "SpectrumAnalyzer.h"
#include "ReferenceTrackAnalyzer.h"
#include "MatchingEQ.h"

class NexusMatchAudioProcessor : public juce::AudioProcessor
{
public:
    NexusMatchAudioProcessor();
    ~NexusMatchAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override  { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    /** Recomputes the matching filter target from the current live +
        reference curves and the "amount" parameter. Call from the UI timer
        (message thread) — see MatchingEQ's threading note for why this
        isn't done per-block on the audio thread. */
    void updateMatchingFilters();

    SpectrumAnalyzer liveAnalyzer;
    ReferenceTrackAnalyzer referenceAnalyzer;

private:
    MatchingEQ matchingEq;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (NexusMatchAudioProcessor)
};
