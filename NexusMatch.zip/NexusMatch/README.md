# Nexus Match — JUCE Reference-Matching EQ (Starter Scaffold)

Step 2 of the roadmap: load a reference track, compare its spectral shape
against your live input in real time, and blend a 24-band filter bank
toward the target curve. This is the "REFERENCE"-style tool.

## How it works

1. **`ReferenceTrackAnalyzer`** loads a user-picked file on a background
   `std::thread`, runs a windowed FFT across the whole file (50% overlap),
   bins the magnitude into 24 log-spaced bands (`BandLayout`), and averages
   across all frames into one per-band dB curve. The curve is normalized
   (mean subtracted) so it represents tonal *shape*, not loudness.
2. **`SpectrumAnalyzer`** does the same band-averaging in real time on the
   live input, with attack/release smoothing so the curve doesn't flicker.
3. **`PluginProcessor::updateMatchingFilters()`** (called from the editor's
   UI timer, a few times a second — not per audio block) computes
   `diff = referenceCurve - liveCurve`, scales it by the "Match Amount"
   parameter, and hands it to...
4. **`MatchingEQ`** — 24 peaking `juce::dsp::IIR` filters, one centred on
   each band, whose gains are set from that diff curve. Audio is processed
   through all 24 in series every block.
5. **`CurveDisplay`** overlays live (cyan) vs. reference (orange) so you can
   see the target before/while it's applied.

## Build

Same as Nexus Meter:
```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```
Needs CMake 3.22+, a C++17 compiler, and internet access on first configure
(FetchContent clones JUCE). Built plugins land in
`build/NexusMatch_artefacts/Release/{VST3,AU,Standalone}/`.

## Known simplifications to fix before shipping

1. **Filter coefficient updates aren't audio-thread-safe in the strict
   sense** — `MatchingEQ::setTargetCurve()` reassigns
   `IIR::Coefficients::Ptr` from the message thread while the audio thread
   reads it. This is the pattern JUCE's own tutorials use and is fine at a
   few updates/second, but a production build should move to a proper
   lock-free double-buffer or `SmoothedValue`-driven coefficient
   interpolation to eliminate any theoretical click risk.
2. **24 fixed bands, not adaptive** — real matching-EQ tools (Ozone's
   Match EQ, TDR Nova, etc.) often use adaptive/variable band counts or a
   full FFT-resolution curve with smarter smoothing. 24 log-spaced bands is
   a reasonable, CPU-cheap starting point; increase `BandLayout::kNumBands`
   and tighten the peaking `Q` in `MatchingEQ` if you want finer resolution.
3. **No dynamic/spectral awareness** — this matches the *average* spectral
   balance. It doesn't distinguish transient vs. sustained energy, so very
   percussive references can skew the curve. A future version could window
   the analysis to exclude transients or add a "tonal only" pre-filter.
4. **Mono-summed analysis** — both analyzers downmix to mono before FFT.
   Fine for overall tonal balance; extend to per-channel analysis if you
   want the matching EQ to also correct stereo width/balance differences.
5. **MP3 reference tracks** — JUCE's built-in `MP3AudioFormat` is
   read-only, which is all `ReferenceTrackAnalyzer` needs, so this should
   work out of the box, but test with your actual reference library.

## Where this fits the roadmap

1. ✅ Nexus Meter — LUFS/true-peak/correlation metering
2. ✅ **Nexus Match** (this plugin) — reference-based EQ matching
3. **Next: mastering bus chain** — combine Nexus Meter's metering with a
   multiband compressor + limiter (and optionally fold Nexus Match's
   matching engine in as a "tonal balance" module) into one processor —
   this is the first genuinely sellable, single-plugin product
4. **Exhale-style spectral/stem tooling** — separate R&D track, doesn't
   block the above
