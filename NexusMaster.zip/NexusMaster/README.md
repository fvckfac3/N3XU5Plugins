# Nexus Master — JUCE Mastering Bus Chain (Starter Scaffold)

Step 3 of the roadmap: combines Nexus Meter's metering with a 3-band
multiband compressor and an output limiter into one processor — the first
plugin in this series meant to be a complete, sellable product on its own.

## Signal flow

```
input ──> [input LUFS meter] ──> bypass? ──┬── yes ──────────────────┐
                                            │                         │
                                            no                        │
                                            ▼                         │
                                 ┌─ LR4 crossover split ─┐            │
                                 │  low / mid / high     │            │
                                 └───────────┬───────────┘            │
                                    per-band Compressor               │
                                    + makeup gain, then sum            │
                                            │                         │
                                            ▼                         │
                                      output Limiter                  │
                                            │                         │
                                            ▼                         ▼
                                  [output LUFS meter] <────────────────
                                  [correlation meter]
                                  [spectrum analyzer]
```

## What's here

- **`LR4Filter.h`** — 4th-order Linkwitz-Riley crossover (two cascaded
  Butterworth stages), used to split the band without introducing the
  frequency-response bump a single-stage crossover would cause.
- **`MultibandCompressor.{h,cpp}`** — splits into low/mid/high via two LR4
  crossovers, runs a `juce::dsp::Compressor` per band, applies makeup gain,
  sums the bands back together. Exposes a per-band gain-reduction estimate
  for the UI meters.
- **`LUFSMeter.{h,cpp}` / `CorrelationMeter.{h,cpp}`** — carried over from
  Nexus Meter unchanged; used twice here (input and output) so you can see
  exactly how much louder/different the chain makes your material.
- **`PluginProcessor.{h,cpp}`** — wires it all together: input metering →
  multiband compression → limiter → output metering, in that order.
- **`BandStrip.{h,cpp}`** — one reusable UI control block (threshold,
  ratio, attack, release, makeup + a small GR meter) instantiated three
  times, once per band.
- **`PluginEditor.{h,cpp}`** — full layout: bypass, crossover frequencies,
  three band strips, limiter controls, and the metering row (input/output
  LUFS, correlation, spectrum).

## Build

Same as the other two:
```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```
Plugins land in `build/NexusMaster_artefacts/Release/{VST3,AU,Standalone}/`.

## Known simplifications to fix before shipping

1. **No parameter smoothing.** `updateDspFromParameters()` re-reads every
   parameter and reassigns filter/compressor state every block. Fine for
   testing, but automating threshold or crossover frequency quickly will
   click. Fix with `juce::SmoothedValue` on each parameter, or by only
   recomputing crossover coefficients when the frequency actually changed
   by more than some epsilon.
2. **Limiter is `juce::dsp::Limiter`, not a true lookahead brickwall.**
   JUCE's built-in limiter is a fast compressor-style limiter with no
   lookahead delay compensation — it can still let transients through
   above the ceiling on fast material. A mastering-grade limiter (like
   what you'd want to actually compete with commercial tools) needs a
   proper lookahead + delay-compensated design; that's a good next
   iteration once this scaffold is compiling and the rest of the chain is
   validated.
3. **Gain-reduction metering is approximate.** Both the per-band GR meters
   and the limiter GR readout are computed by comparing peak/RMS before vs.
   after processing, not read directly from the compressor's internal
   envelope. Close enough to see what's happening, not accurate enough to
   calibrate against.
4. **Crossover ordering isn't enforced in the UI.** The processor clamps
   `crossoverHigh` to at least `1.5x crossoverLow` internally, but the two
   sliders don't visually prevent you from setting them close together —
   worth adding a UI-level constraint.
5. **Mono-summed GR estimate** — `MultibandCompressor` reads channel 0 only
   for its RMS-based gain reduction estimate; extend to average both
   channels if you want a more representative reading on hard-panned
   material.

## Where this fits the roadmap

1. ✅ Nexus Meter — LUFS/true-peak/correlation metering
2. ✅ Nexus Match — reference-based EQ matching
3. ✅ **Nexus Master** (this plugin) — multiband compression + limiting +
   metering, the first complete mastering-chain product
4. **Next: Exhale-style spectral/stem tooling** — separate R&D track.
   Classical spectral gating (median-filter-based transient/tonal
   separation) gets you most of the way to something useful; genuine
   source-separation quality needs a trained model (Demucs-style) run via
   ONNX Runtime inside the plugin. Don't block shipping 1-3 on this.

## Licensing / distribution

Same notes as the other two scaffolds: manufacturer/plugin codes in
`CMakeLists.txt` are placeholders, and no copy-protection is implemented.
Nexus Master is the first of the three with genuine standalone commercial
potential — worth deciding on a license-key/purchase flow (Gumroad/Paddle +
a serial check) before you put it in front of customers.
