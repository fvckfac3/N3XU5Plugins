#pragma once
#include <juce_dsp/juce_dsp.h>
#include <deque>

/**
    LUFSMeter — same implementation as used in Nexus Meter. See that
    project's README for the known spec-compliance simplifications
    (relative gating not yet implemented, true-peak filter is an
    approximation). Used here twice: once on the input (pre-processing)
    and once on the output (post-processing) so you can see the loudness
    change your mastering chain is making in real time.
*/
class LUFSMeter
{
public:
    LUFSMeter() = default;

    void prepare (double sampleRate, int numChannels, int maxBlockSize);
    void reset();
    void processBlock (const juce::AudioBuffer<float>& buffer);

    float getMomentaryLUFS() const   { return momentaryLUFS.load(); }
    float getShortTermLUFS() const   { return shortTermLUFS.load(); }
    float getIntegratedLUFS() const  { return integratedLUFS.load(); }
    float getTruePeakDb() const      { return truePeakDb.load(); }
    float getRmsDb() const           { return rmsDb.load(); }

private:
    double sr = 44100.0;
    int numChans = 2;

    std::vector<juce::dsp::IIR::Filter<float>> preFilters;
    std::vector<juce::dsp::IIR::Filter<float>> rlbFilters;

    std::unique_ptr<juce::dsp::Oversampling<float>> oversampler;

    std::deque<double> blockMeanSquares;
    double blockAccumulator = 0.0;
    int blockSampleCount = 0;
    int samplesPer100ms = 4410;

    std::atomic<float> momentaryLUFS { -70.0f };
    std::atomic<float> shortTermLUFS { -70.0f };
    std::atomic<float> integratedLUFS { -70.0f };
    std::atomic<float> truePeakDb { -100.0f };
    std::atomic<float> rmsDb { -100.0f };

    double gatedSumSquares = 0.0;
    int gatedBlockCount = 0;

    static double meanSquareToLUFS (double meanSquare);
    void updateKWeightingCoefficients();
};
