#include "BandStrip.h"

BandStrip::BandStrip (juce::AudioProcessorValueTreeState& apvts, const juce::String& bandId,
                       const juce::String& displayName, juce::Colour accentColour)
    : name (displayName), colour (accentColour)
{
    setupSlider (thresholdSlider, thresholdLabel);
    setupSlider (ratioSlider, ratioLabel);
    setupSlider (attackSlider, attackLabel);
    setupSlider (releaseSlider, releaseLabel);
    setupSlider (makeupSlider, makeupLabel);

    thresholdAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (apvts, bandId + "Threshold", thresholdSlider);
    ratioAttach     = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (apvts, bandId + "Ratio", ratioSlider);
    attackAttach    = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (apvts, bandId + "Attack", attackSlider);
    releaseAttach   = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (apvts, bandId + "Release", releaseSlider);
    makeupAttach    = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (apvts, bandId + "Makeup", makeupSlider);
}

void BandStrip::setupSlider (juce::Slider& s, juce::Label& l)
{
    s.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 56, 16);
    addAndMakeVisible (s);

    l.setJustificationType (juce::Justification::centred);
    l.setFont (juce::Font (juce::FontOptions (11.0f)));
    l.setColour (juce::Label::textColourId, juce::Colours::white.withAlpha (0.7f));
    addAndMakeVisible (l);
}

void BandStrip::paint (juce::Graphics& g)
{
    auto bounds = getLocalBounds().toFloat();
    g.setColour (juce::Colour (0xff141420));
    g.fillRoundedRectangle (bounds, 6.0f);

    g.setColour (colour);
    g.setFont (juce::Font (juce::FontOptions (14.0f)).withTypefaceStyle ("Bold"));
    g.drawText (name, bounds.removeFromTop (20.0f).toNearestInt(), juce::Justification::centred);

    // Gain-reduction meter along the right edge — fills downward from the top
    // as reduction increases, the usual convention for a GR meter.
    auto grArea = getLocalBounds().removeFromRight (14).reduced (2, 24).toFloat();
    g.setColour (juce::Colours::black.withAlpha (0.4f));
    g.fillRoundedRectangle (grArea, 2.0f);
    const float norm = juce::jlimit (0.0f, 1.0f, -gainReductionDb / 24.0f);
    auto fill = grArea.removeFromTop (grArea.getHeight() * norm);
    g.setColour (colour);
    g.fillRoundedRectangle (fill, 2.0f);
}

void BandStrip::resized()
{
    auto bounds = getLocalBounds().reduced (4);
    bounds.removeFromTop (22);   // title
    bounds.removeFromRight (18); // GR meter space

    const int w = bounds.getWidth() / 5;
    auto layoutOne = [&] (juce::Slider& s, juce::Label& l)
    {
        auto col = bounds.removeFromLeft (w);
        l.setBounds (col.removeFromTop (14));
        s.setBounds (col);
    };
    layoutOne (thresholdSlider, thresholdLabel);
    layoutOne (ratioSlider, ratioLabel);
    layoutOne (attackSlider, attackLabel);
    layoutOne (releaseSlider, releaseLabel);
    layoutOne (makeupSlider, makeupLabel);
}
