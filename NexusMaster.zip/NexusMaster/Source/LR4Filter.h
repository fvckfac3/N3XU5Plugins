#pragma once
#include <juce_dsp/juce_dsp.h>

/**
    LR4Filter
    ----------
    A 4th-order (24dB/oct) Linkwitz-Riley filter built from two cascaded
    2nd-order Butterworth stages (Q = 0.7071) at the same cutoff frequency.
    A matched LR4 lowpass/highpass pair, summed together, reconstructs the
    original signal's magnitude response flat — the standard technique for
    a crossover network.

    Implemented on top of juce::dsp::IIR rather than a dedicated
    Linkwitz-Riley class so the API surface here is small and stable across
    JUCE versions.
*/
class LR4Filter
{
public:
    enum class Type { lowpass, highpass };

    explicit LR4Filter (Type t) : type (t) {}

    void prepare (const juce::dsp::ProcessSpec& spec)
    {
        stage1.prepare (spec);
        stage2.prepare (spec);
    }

    void reset()
    {
        stage1.reset();
        stage2.reset();
    }

    void setCutoff (double sampleRate, float frequency)
    {
        auto coeffs = (type == Type::lowpass)
            ? juce::dsp::IIR::Coefficients<float>::makeLowPass (sampleRate, frequency, 0.7071f)
            : juce::dsp::IIR::Coefficients<float>::makeHighPass (sampleRate, frequency, 0.7071f);
        stage1.state = coeffs;
        stage2.state = coeffs;
    }

    void process (juce::dsp::ProcessContextReplacing<float> context)
    {
        stage1.process (context);
        stage2.process (context);
    }

private:
    Type type;
    juce::dsp::ProcessorDuplicator<juce::dsp::IIR::Filter<float>, juce::dsp::IIR::Coefficients<float>> stage1, stage2;
};
