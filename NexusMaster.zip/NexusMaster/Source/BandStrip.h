#pragma once
#include <juce_audio_processors/juce_audio_processors.h>

/**
    BandStrip
    ----------
    Threshold/ratio/attack/release/makeup controls for one compressor band,
    plus a small vertical gain-reduction meter on the right edge. One
    instance per band (low/mid/high) — parameter IDs are built from the
    bandId prefix passed in (e.g. "low" -> "lowThreshold", "lowRatio", ...),
    matching NexusMasterAudioProcessor::createParameterLayout().
*/
class BandStrip : public juce::Component
{
public:
    BandStrip (juce::AudioProcessorValueTreeState& apvts, const juce::String& bandId,
               const juce::String& displayName, juce::Colour accentColour);

    void paint (juce::Graphics& g) override;
    void resized() override;

    void setGainReduction (float grDb) { gainReductionDb = grDb; repaint(); }

private:
    juce::String name;
    juce::Colour colour;

    juce::Slider thresholdSlider, ratioSlider, attackSlider, releaseSlider, makeupSlider;
    juce::Label thresholdLabel { {}, "Thresh" }, ratioLabel { {}, "Ratio" },
                attackLabel { {}, "Attack" }, releaseLabel { {}, "Release" }, makeupLabel { {}, "Makeup" };

    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>
        thresholdAttach, ratioAttach, attackAttach, releaseAttach, makeupAttach;

    float gainReductionDb = 0.0f;

    void setupSlider (juce::Slider&, juce::Label&);
};
