#pragma once
#include <juce_dsp/juce_dsp.h>

/** CorrelationMeter — same implementation as Nexus Meter. Running L/R phase correlation, -1..+1. */
class CorrelationMeter
{
public:
    void prepare (double sampleRate);
    void reset();
    void processBlock (const juce::AudioBuffer<float>& buffer);

    float getCorrelation() const { return correlation.load(); }

private:
    double sr = 44100.0;
    double smoothingCoeff = 0.99;
    double runningLL = 0.0, runningRR = 0.0, runningLR = 0.0;
    std::atomic<float> correlation { 1.0f };
};
