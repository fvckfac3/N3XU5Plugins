#include "PluginEditor.h"

NexusMasterAudioProcessorEditor::NexusMasterAudioProcessorEditor (NexusMasterAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p),
      lowStrip  (p.apvts, "low",  "LOW",  juce::Colour (0xff00e5c7)),
      midStrip  (p.apvts, "mid",  "MID",  juce::Colour (0xffffc93c)),
      highStrip (p.apvts, "high", "HIGH", juce::Colour (0xffff2d78))
{
    addAndMakeVisible (bypassButton);
    bypassAttach = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
        audioProcessor.apvts, "bypass", bypassButton);

    setupSmallSlider (targetLufsSlider, targetLufsLabel);
    targetLufsAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, "targetLufs", targetLufsSlider);

    setupSmallSlider (crossoverLowSlider, crossoverLowLabel);
    crossoverLowAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, "crossoverLow", crossoverLowSlider);

    setupSmallSlider (crossoverHighSlider, crossoverHighLabel);
    crossoverHighAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, "crossoverHigh", crossoverHighSlider);

    addAndMakeVisible (lowStrip);
    addAndMakeVisible (midStrip);
    addAndMakeVisible (highStrip);

    setupSmallSlider (limiterCeilingSlider, limiterCeilingLabel);
    limiterCeilingAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, "limiterCeiling", limiterCeilingSlider);

    setupSmallSlider (limiterReleaseSlider, limiterReleaseLabel);
    limiterReleaseAttach = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.apvts, "limiterRelease", limiterReleaseSlider);

    limiterGrMeter.setRange (-24.0f, 0.0f);
    limiterGrMeter.setLabel ("Limiter GR");
    addAndMakeVisible (limiterGrMeter);

    inputLufsMeterDisplay.setRange (-40.0f, 0.0f);
    inputLufsMeterDisplay.setLabel ("In LUFS");
    addAndMakeVisible (inputLufsMeterDisplay);

    outputLufsMeterDisplay.setRange (-40.0f, 0.0f);
    outputLufsMeterDisplay.setLabel ("Out LUFS");
    addAndMakeVisible (outputLufsMeterDisplay);

    addAndMakeVisible (correlationDisplay);
    addAndMakeVisible (spectrumDisplay);

    setSize (920, 720);
    setResizable (true, true);
    setResizeLimits (700, 560, 1400, 1000);

    startTimerHz (30);
}

void NexusMasterAudioProcessorEditor::setupSmallSlider (juce::Slider& s, juce::Label& l)
{
    s.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 70, 16);
    addAndMakeVisible (s);

    l.setJustificationType (juce::Justification::centred);
    l.setColour (juce::Label::textColourId, juce::Colours::white.withAlpha (0.7f));
    l.setFont (juce::Font (juce::FontOptions (11.0f)));
    addAndMakeVisible (l);
}

void NexusMasterAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colour (0xff0a0a0f));
    g.setColour (juce::Colours::white);
    g.setFont (juce::Font (juce::FontOptions (20.0f)).withTypefaceStyle ("Bold"));
    g.drawText ("NEXUS MASTER", getLocalBounds().removeFromTop (36).reduced (12, 0),
                juce::Justification::centredLeft);
}

void NexusMasterAudioProcessorEditor::resized()
{
    auto bounds = getLocalBounds().reduced (12);
    bounds.removeFromTop (36); // title space

    auto topRow = bounds.removeFromTop (30);
    bypassButton.setBounds (topRow.removeFromLeft (90));

    bounds.removeFromTop (8);

    auto controlsRow = bounds.removeFromTop (70);
    auto layoutSmall = [&] (juce::Rectangle<int>& row, juce::Label& l, juce::Slider& s, int w)
    {
        auto col = row.removeFromLeft (w);
        l.setBounds (col.removeFromTop (14));
        s.setBounds (col);
        row.removeFromLeft (12);
    };
    layoutSmall (controlsRow, crossoverLowLabel, crossoverLowSlider, 90);
    layoutSmall (controlsRow, crossoverHighLabel, crossoverHighSlider, 90);
    controlsRow.removeFromLeft (16);
    layoutSmall (controlsRow, targetLufsLabel, targetLufsSlider, 90);

    bounds.removeFromTop (10);

    auto bandRow = bounds.removeFromTop (170);
    const int bandWidth = bandRow.getWidth() / 3;
    lowStrip.setBounds (bandRow.removeFromLeft (bandWidth).reduced (4));
    midStrip.setBounds (bandRow.removeFromLeft (bandWidth).reduced (4));
    highStrip.setBounds (bandRow.reduced (4));

    bounds.removeFromTop (10);

    auto limiterRow = bounds.removeFromTop (90);
    layoutSmall (limiterRow, limiterCeilingLabel, limiterCeilingSlider, 90);
    layoutSmall (limiterRow, limiterReleaseLabel, limiterReleaseSlider, 90);
    limiterRow.removeFromLeft (8);
    limiterGrMeter.setBounds (limiterRow.removeFromLeft (80));

    bounds.removeFromTop (10);

    auto meterRow = bounds.removeFromTop (140);
    inputLufsMeterDisplay.setBounds (meterRow.removeFromLeft (90));
    meterRow.removeFromLeft (8);
    outputLufsMeterDisplay.setBounds (meterRow.removeFromLeft (90));
    meterRow.removeFromLeft (8);
    correlationDisplay.setBounds (meterRow.removeFromLeft (160).withSizeKeepingCentre (160, 40));
    meterRow.removeFromLeft (8);
    spectrumDisplay.setBounds (meterRow);
}

void NexusMasterAudioProcessorEditor::timerCallback()
{
    lowStrip.setGainReduction (audioProcessor.getBandGainReduction (0));
    midStrip.setGainReduction (audioProcessor.getBandGainReduction (1));
    highStrip.setGainReduction (audioProcessor.getBandGainReduction (2));

    limiterGrMeter.setValue (audioProcessor.getLimiterGainReductionDb());
    inputLufsMeterDisplay.setValue (audioProcessor.inputLufsMeter.getShortTermLUFS());
    outputLufsMeterDisplay.setValue (audioProcessor.outputLufsMeter.getShortTermLUFS());
    correlationDisplay.setCorrelation (audioProcessor.correlationMeter.getCorrelation());
    spectrumDisplay.updateFromProcessor();
}
