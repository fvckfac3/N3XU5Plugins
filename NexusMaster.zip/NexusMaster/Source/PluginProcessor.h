#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "LUFSMeter.h"
#include "CorrelationMeter.h"
#include "MultibandCompressor.h"

class NexusMasterAudioProcessor : public juce::AudioProcessor
{
public:
    NexusMasterAudioProcessor();
    ~NexusMasterAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override  { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    LUFSMeter inputLufsMeter, outputLufsMeter;
    CorrelationMeter correlationMeter;
    MultibandCompressor multibandCompressor;

    float getBandGainReduction (int band) const { return multibandCompressor.getGainReductionDb (band); }
    float getLimiterGainReductionDb() const { return limiterGainReductionDb.load(); }

    // Output spectrum analyzer feed (post-processing), read by the editor's SpectrumDisplay
    static constexpr int fftOrder = 11;
    static constexpr int fftSize = 1 << fftOrder;
    juce::dsp::FFT fft { fftOrder };
    juce::dsp::WindowingFunction<float> fftWindow { (size_t) fftSize, juce::dsp::WindowingFunction<float>::hann };
    std::array<float, fftSize * 2> fftData {};
    std::array<float, fftSize> fifo {};
    int fifoIndex = 0;
    std::atomic<bool> fftDataReady { false };
    juce::CriticalSection fftLock;

private:
    juce::dsp::Limiter<float> limiter;
    std::atomic<float> limiterGainReductionDb { 0.0f };

    void pushNextSampleIntoFifo (float sample);
    void updateDspFromParameters();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (NexusMasterAudioProcessor)
};
