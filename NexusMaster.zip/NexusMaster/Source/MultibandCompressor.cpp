#include "MultibandCompressor.h"

void MultibandCompressor::prepare (const juce::dsp::ProcessSpec& spec)
{
    sampleRate = spec.sampleRate;

    lowMidLPF.prepare (spec);
    lowMidHPF.prepare (spec);
    midHighLPF.prepare (spec);
    midHighHPF.prepare (spec);

    for (auto& c : compressors) c.prepare (spec);

    setCrossoverFrequencies (200.0f, 2000.0f);
}

void MultibandCompressor::reset()
{
    lowMidLPF.reset();
    lowMidHPF.reset();
    midHighLPF.reset();
    midHighHPF.reset();
    for (auto& c : compressors) c.reset();
}

void MultibandCompressor::setCrossoverFrequencies (float lowMidHz, float midHighHz)
{
    lowMidLPF.setCutoff (sampleRate, lowMidHz);
    lowMidHPF.setCutoff (sampleRate, lowMidHz);
    midHighLPF.setCutoff (sampleRate, midHighHz);
    midHighHPF.setCutoff (sampleRate, midHighHz);
}

void MultibandCompressor::setBandParams (int band, float thresholdDb, float ratio, float attackMs, float releaseMs, float makeupDb)
{
    auto& c = compressors[(size_t) band];
    c.setThreshold (thresholdDb);
    c.setRatio (ratio);
    c.setAttack (attackMs);
    c.setRelease (releaseMs);
    makeupGainDb[(size_t) band] = makeupDb;
}

void MultibandCompressor::process (juce::AudioBuffer<float>& buffer)
{
    const int numCh = buffer.getNumChannels();
    const int numSamples = buffer.getNumSamples();

    lowBuffer.setSize (numCh, numSamples, false, false, true);
    restBuffer.setSize (numCh, numSamples, false, false, true);
    midBuffer.setSize (numCh, numSamples, false, false, true);
    highBuffer.setSize (numCh, numSamples, false, false, true);

    lowBuffer.makeCopyOf (buffer, true);
    restBuffer.makeCopyOf (buffer, true);

    // First crossover: low vs. (mid+high)
    {
        juce::dsp::AudioBlock<float> lowBlock (lowBuffer);
        lowMidLPF.process (juce::dsp::ProcessContextReplacing<float> (lowBlock));
        juce::dsp::AudioBlock<float> restBlock (restBuffer);
        lowMidHPF.process (juce::dsp::ProcessContextReplacing<float> (restBlock));
    }

    midBuffer.makeCopyOf (restBuffer, true);
    highBuffer.makeCopyOf (restBuffer, true);

    // Second crossover: mid vs. high
    {
        juce::dsp::AudioBlock<float> midBlock (midBuffer);
        midHighLPF.process (juce::dsp::ProcessContextReplacing<float> (midBlock));
        juce::dsp::AudioBlock<float> highBlock (highBuffer);
        midHighHPF.process (juce::dsp::ProcessContextReplacing<float> (highBlock));
    }

    std::array<juce::AudioBuffer<float>*, numBands> bandBuffers { &lowBuffer, &midBuffer, &highBuffer };

    for (int b = 0; b < numBands; ++b)
    {
        auto& bb = *bandBuffers[(size_t) b];
        const float preRms = bb.getRMSLevel (0, 0, numSamples);

        juce::dsp::AudioBlock<float> block (bb);
        compressors[(size_t) b].process (juce::dsp::ProcessContextReplacing<float> (block));
        bb.applyGain (juce::Decibels::decibelsToGain (makeupGainDb[(size_t) b]));

        const float postRms = bb.getRMSLevel (0, 0, numSamples);
        const float grDb = juce::Decibels::gainToDecibels (juce::jmax (postRms, 1.0e-8f))
                          - juce::Decibels::gainToDecibels (juce::jmax (preRms, 1.0e-8f))
                          - makeupGainDb[(size_t) b];
        gainReductionDb[(size_t) b] = juce::jmin (0.0f, grDb);
    }

    buffer.clear();
    for (int b = 0; b < numBands; ++b)
        for (int ch = 0; ch < numCh; ++ch)
            buffer.addFrom (ch, 0, *bandBuffers[(size_t) b], ch, 0, numSamples);
}
