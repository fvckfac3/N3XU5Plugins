#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include "MeterComponent.h"
#include "BandStrip.h"

class NexusMasterAudioProcessorEditor : public juce::AudioProcessorEditor,
                                         private juce::Timer
{
public:
    explicit NexusMasterAudioProcessorEditor (NexusMasterAudioProcessor&);
    ~NexusMasterAudioProcessorEditor() override = default;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void setupSmallSlider (juce::Slider&, juce::Label&);

    NexusMasterAudioProcessor& audioProcessor;

    juce::ToggleButton bypassButton { "Bypass" };
    juce::Slider targetLufsSlider;
    juce::Label targetLufsLabel { {}, "Target LUFS" };

    juce::Slider crossoverLowSlider, crossoverHighSlider;
    juce::Label crossoverLowLabel { {}, "Low/Mid" }, crossoverHighLabel { {}, "Mid/High" };

    BandStrip lowStrip, midStrip, highStrip;

    juce::Slider limiterCeilingSlider, limiterReleaseSlider;
    juce::Label limiterCeilingLabel { {}, "Ceiling" }, limiterReleaseLabel { {}, "Release" };
    BarMeter limiterGrMeter;

    BarMeter inputLufsMeterDisplay, outputLufsMeterDisplay;
    CorrelationDisplay correlationDisplay;
    SpectrumDisplay spectrumDisplay { audioProcessor };

    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>
        targetLufsAttach, crossoverLowAttach, crossoverHighAttach, limiterCeilingAttach, limiterReleaseAttach;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttach;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (NexusMasterAudioProcessorEditor)
};
