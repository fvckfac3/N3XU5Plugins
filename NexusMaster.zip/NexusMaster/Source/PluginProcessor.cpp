#include "PluginProcessor.h"
#include "PluginEditor.h"

NexusMasterAudioProcessor::NexusMasterAudioProcessor()
    : AudioProcessor (BusesProperties()
                         .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                         .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMETERS", createParameterLayout())
{
}

juce::AudioProcessorValueTreeState::ParameterLayout NexusMasterAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "crossoverLow", "Crossover Low",
        juce::NormalisableRange<float> (40.0f, 1000.0f, 1.0f, 0.3f), 200.0f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "crossoverHigh", "Crossover High",
        juce::NormalisableRange<float> (500.0f, 8000.0f, 1.0f, 0.3f), 2000.0f));

    auto addBandParams = [&params] (const juce::String& id, const juce::String& name)
    {
        params.push_back (std::make_unique<juce::AudioParameterFloat> (
            id + "Threshold", name + " Threshold",
            juce::NormalisableRange<float> (-60.0f, 0.0f, 0.1f), -18.0f));
        params.push_back (std::make_unique<juce::AudioParameterFloat> (
            id + "Ratio", name + " Ratio",
            juce::NormalisableRange<float> (1.0f, 20.0f, 0.1f, 0.4f), 3.0f));
        params.push_back (std::make_unique<juce::AudioParameterFloat> (
            id + "Attack", name + " Attack",
            juce::NormalisableRange<float> (0.1f, 100.0f, 0.1f, 0.3f), 10.0f));
        params.push_back (std::make_unique<juce::AudioParameterFloat> (
            id + "Release", name + " Release",
            juce::NormalisableRange<float> (10.0f, 1000.0f, 1.0f, 0.3f), 100.0f));
        params.push_back (std::make_unique<juce::AudioParameterFloat> (
            id + "Makeup", name + " Makeup",
            juce::NormalisableRange<float> (-12.0f, 12.0f, 0.1f), 0.0f));
    };
    addBandParams ("low", "Low");
    addBandParams ("mid", "Mid");
    addBandParams ("high", "High");

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "limiterCeiling", "Limiter Ceiling",
        juce::NormalisableRange<float> (-6.0f, 0.0f, 0.1f), -0.3f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "limiterRelease", "Limiter Release",
        juce::NormalisableRange<float> (10.0f, 500.0f, 1.0f, 0.3f), 50.0f));

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "targetLufs", "Target LUFS",
        juce::NormalisableRange<float> (-40.0f, -6.0f, 0.1f), -14.0f));

    params.push_back (std::make_unique<juce::AudioParameterBool> ("bypass", "Bypass", false));

    return { params.begin(), params.end() };
}

void NexusMasterAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    inputLufsMeter.prepare (sampleRate, getTotalNumInputChannels(), samplesPerBlock);
    outputLufsMeter.prepare (sampleRate, getTotalNumInputChannels(), samplesPerBlock);
    correlationMeter.prepare (sampleRate);

    juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) samplesPerBlock,
                                   (juce::uint32) juce::jmax (1, getTotalNumOutputChannels()) };
    multibandCompressor.prepare (spec);
    limiter.prepare (spec);

    fifoIndex = 0;
    fifo.fill (0.0f);
}

bool NexusMasterAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto mono = juce::AudioChannelSet::mono();
    const auto stereo = juce::AudioChannelSet::stereo();
    auto in = layouts.getMainInputChannelSet();
    auto out = layouts.getMainOutputChannelSet();
    if (in != out) return false;
    return in == mono || in == stereo;
}

void NexusMasterAudioProcessor::updateDspFromParameters()
{
    float loFreq = apvts.getRawParameterValue ("crossoverLow")->load();
    float hiFreq = apvts.getRawParameterValue ("crossoverHigh")->load();
    hiFreq = juce::jmax (hiFreq, loFreq * 1.5f); // keep the two crossovers from crossing/inverting order
    multibandCompressor.setCrossoverFrequencies (loFreq, hiFreq);

    auto setBand = [this] (int band, const juce::String& id)
    {
        multibandCompressor.setBandParams (band,
            apvts.getRawParameterValue (id + "Threshold")->load(),
            apvts.getRawParameterValue (id + "Ratio")->load(),
            apvts.getRawParameterValue (id + "Attack")->load(),
            apvts.getRawParameterValue (id + "Release")->load(),
            apvts.getRawParameterValue (id + "Makeup")->load());
    };
    setBand (0, "low");
    setBand (1, "mid");
    setBand (2, "high");

    limiter.setThreshold (apvts.getRawParameterValue ("limiterCeiling")->load());
    limiter.setRelease (apvts.getRawParameterValue ("limiterRelease")->load());
}

void NexusMasterAudioProcessor::pushNextSampleIntoFifo (float sample)
{
    if (fifoIndex == fftSize)
    {
        if (! fftDataReady.load())
        {
            juce::ScopedLock lock (fftLock);
            std::fill (fftData.begin(), fftData.end(), 0.0f);
            std::copy (fifo.begin(), fifo.end(), fftData.begin());
            fftDataReady = true;
        }
        fifoIndex = 0;
    }
    fifo[(size_t) fifoIndex++] = sample;
}

void NexusMasterAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    inputLufsMeter.processBlock (buffer);

    const bool bypassed = apvts.getRawParameterValue ("bypass")->load() > 0.5f;

    if (! bypassed)
    {
        // NOTE: pulling parameters and reassigning filter/compressor state every
        // block is simple and fine for a starter scaffold, but it's not
        // click-free under fast automation — a shipping version should
        // smooth crossover frequency and threshold/ratio changes rather than
        // snapping them each block.
        updateDspFromParameters();

        multibandCompressor.process (buffer);

        const float prePeak = buffer.getMagnitude (0, buffer.getNumSamples());
        juce::dsp::AudioBlock<float> block (buffer);
        limiter.process (juce::dsp::ProcessContextReplacing<float> (block));
        const float postPeak = buffer.getMagnitude (0, buffer.getNumSamples());
        limiterGainReductionDb = juce::Decibels::gainToDecibels (juce::jmax (postPeak, 1.0e-8f))
                                - juce::Decibels::gainToDecibels (juce::jmax (prePeak, 1.0e-8f));
    }

    outputLufsMeter.processBlock (buffer);
    correlationMeter.processBlock (buffer);

    if (buffer.getNumChannels() > 0)
    {
        const auto* readPtr = buffer.getReadPointer (0);
        for (int i = 0; i < buffer.getNumSamples(); ++i)
            pushNextSampleIntoFifo (readPtr[i]);
    }
}

juce::AudioProcessorEditor* NexusMasterAudioProcessor::createEditor()
{
    return new NexusMasterAudioProcessorEditor (*this);
}

void NexusMasterAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void NexusMasterAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, sizeInBytes));
    if (xml != nullptr && xml->hasTagName (apvts.state.getType()))
        apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new NexusMasterAudioProcessor();
}
