#pragma once
#include <juce_dsp/juce_dsp.h>
#include "LR4Filter.h"

/**
    MultibandCompressor
    ---------------------
    Splits the signal into low/mid/high bands via two LR4 crossovers,
    compresses each band independently, applies per-band makeup gain, and
    sums the bands back together.

    Gain-reduction metering is approximated by comparing each band's RMS
    level (channel 0 only) before vs. after compression — a cheap estimate
    for a UI meter, not a sample-accurate GR readout. Good enough to see
    "the mid band is working," not for measurement/calibration purposes.
*/
class MultibandCompressor
{
public:
    static constexpr int numBands = 3; // 0 = low, 1 = mid, 2 = high

    void prepare (const juce::dsp::ProcessSpec& spec);
    void reset();
    void process (juce::AudioBuffer<float>& buffer);

    void setCrossoverFrequencies (float lowMidHz, float midHighHz);
    void setBandParams (int band, float thresholdDb, float ratio, float attackMs, float releaseMs, float makeupDb);

    float getGainReductionDb (int band) const { return gainReductionDb[(size_t) band].load(); }

private:
    double sampleRate = 44100.0;

    LR4Filter lowMidLPF  { LR4Filter::Type::lowpass };
    LR4Filter lowMidHPF  { LR4Filter::Type::highpass };
    LR4Filter midHighLPF { LR4Filter::Type::lowpass };
    LR4Filter midHighHPF { LR4Filter::Type::highpass };

    std::array<juce::dsp::Compressor<float>, numBands> compressors;
    std::array<float, numBands> makeupGainDb { 0.0f, 0.0f, 0.0f };
    std::array<std::atomic<float>, numBands> gainReductionDb { {0.0f, 0.0f, 0.0f} };

    juce::AudioBuffer<float> lowBuffer, restBuffer, midBuffer, highBuffer;
};
