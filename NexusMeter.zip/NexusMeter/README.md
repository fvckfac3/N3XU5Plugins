# Nexus Meter — JUCE VST3/AU Metering Plugin (Starter Scaffold)

A working project skeleton for a Mastering-The-Mix-style LUFS/true-peak/correlation/
spectrum metering plugin, built on JUCE. This is step 1 of the roadmap: an
analysis-only plugin (no audio modification) so you can learn the plugin
lifecycle, `AudioProcessorValueTreeState`, and custom UI painting before
tackling real-time DSP modification (EQ, dynamics, mastering chain).

## What's here

- `CMakeLists.txt` — pulls JUCE via FetchContent (pinned to 7.0.12) and
  configures VST3 + AU + Standalone build targets.
- `Source/PluginProcessor.{h,cpp}` — plugin lifecycle, parameter tree,
  audio-thread metering calls. Passes audio through unmodified.
- `Source/LUFSMeter.{h,cpp}` — BS.1770-style K-weighted loudness: momentary,
  short-term, integrated (simplified — no relative gate pass yet), plus a
  true-peak estimate via 4x oversampling.
- `Source/CorrelationMeter.{h,cpp}` — running L/R phase correlation.
- `Source/MeterComponent.h` — custom-painted bar meters, correlation needle,
  and a log spectrum display.
- `Source/PluginEditor.{h,cpp}` — lays out the above and refreshes at 30Hz
  via a `juce::Timer` (UI thread reads the processor's atomics — never call
  into UI code from `processBlock`).

## Build

### Prerequisites
- CMake 3.22+
- A C++17 compiler (Xcode on macOS, Visual Studio 2022 on Windows, or
  gcc/clang on Linux)
- Internet access on first configure (FetchContent clones JUCE — if you'd
  rather vendor JUCE locally, see the comment block at the top of
  `CMakeLists.txt`)

### Commands
```bash
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

Built plugins land in `build/NexusMeter_artefacts/Release/{VST3,AU,Standalone}/`.
`COPY_PLUGIN_AFTER_BUILD TRUE` in the CMake config will also copy VST3/AU
into your system plugin folders automatically.

### Load it
- Open the Standalone build directly to test without a DAW, or
- Point Reaper/Ableton/Logic at the VST3/AU and rescan plugins.

## Known simplifications to fix before shipping

1. **Integrated LUFS gating** — BS.1770 spec requires an absolute gate at
   -70 LUFS (implemented) *and* a relative gate at -10dB below the
   ungated mean (not yet implemented). Add a two-pass calculation:
   first pass computes ungated mean, second pass re-sums only blocks
   above `ungatedMean - 10dB`.
2. **Channel weighting** — BS.1770 weights surround channels (Ls/Rs) at
   +1.5dB; current code treats all channels equally. Fine for stereo,
   needs extending for 5.1 material.
3. **True peak** — using `juce::dsp::Oversampling`'s halfband IIR filters
   as an approximation. The BS.1770 spec calls for a specific polyphase
   FIR interpolation filter — swap in `juce::dsp::Oversampling::filterHalfBandFIREquiripple`
   for closer spec compliance, at higher CPU cost.
4. **Validate against a reference meter** (Youlean Loudness Meter is free)
   on real program material before trusting the numbers.

## Roadmap (per our conversation)

1. ✅ **This plugin** — metering/analysis, zero-risk DSP, teaches the framework
2. **EQ/reference matcher** — analyze a reference track's spectral envelope,
   overlay against your mix, suggest EQ moves (`juce::dsp::IIR` + FFT averaging)
3. **Mastering bus chain** — multiband compressor + limiter + the metering
   above, combined into one processor — first genuinely sellable product
4. **Exhale-style spectral/stem tooling** — classical spectral gating gets
   you most of the way; true source separation needs a trained model run
   via ONNX Runtime inside the plugin — separate R&D track, don't block
   the rest of the roadmap on it

## Licensing / distribution (decide before you sell)

- Company/manufacturer codes in `CMakeLists.txt` (`PLUGIN_MANUFACTURER_CODE`,
  `PLUGIN_CODE`) are placeholders — register real ones if you go through
  Steinberg's VST3 program.
- No license-key or copy-protection is implemented here. For a first sale,
  a simple Gumroad/Paddle purchase + serial-check-on-first-run is enough;
  iLok/PACE integration is heavier and usually worth deferring until you
  have revenue to justify it.
